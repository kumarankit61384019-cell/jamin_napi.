# Jamin Napi - Ready-to-Build Flutter Project (Hindi instructions)

यह ज़िप एक **Flutter project bundle** है जिसमें सिर्फ जरूरी फाइलें (lib/main.dart और pubspec.yaml) हैं और एक GitHub Actions workflow शामिल है जो automatic APK बनाकर artifact के रूप में दे देगा।

**महत्वपूर्ण नोट:** इस environment में मैं सीधे APK compile नहीं कर सकता (Android SDK और signing tools यहाँ उपलब्ध नहीं)। पर यह ज़िप आप GitHub पर push करके GitHub Actions से APK बना सकते हैं। नीचे आसान steps दिए गए हैं।

## तरीका — GitHub Actions से APK बनवाना (सफ़ल और आसान)
1. अपने फोन या किसी और डिवाइस से GitHub पर एक नया public या private repository बनाओ (नाम: `jamin_napi`).
2. इस ZIP को extract करो और सारी फाइलें अपने repo में upload कर दो (या सीधे zip upload करके GitHub web पर "Upload files" करो).
3. `main` या `master` branch में commit/push करो।
4. GitHub → Actions tab में जाओ। वहां नया workflow `Build Flutter APK` automatically रन होगा (या `Actions` → workflow_select → "Run workflow")।
5. Actions run complete होने पर उस run के भीतर `Artifacts` section में `jamin_napi_apk` दिखेगा — वहाँ से आप `app-release.apk` डाउनलोड कर सकते हो।
6. APK को अपने फोन पर install करने के लिए:
   - Settings → Security → Unknown sources allow (यदि side-load कर रहे हो)।
   - APK file को फोन पर खोलकर install करो।

## अगर आप चाहो तो मैं और मदद कर सकता हूँ:
- मैं इस repo का ZIP अभी बना कर दे रहा हूँ (नीचे download link) — आप इसे GitHub में upload कर दीजिये।
- या मैं GitHub में repo बनाकर (आपको link दे कर) push कर सकता हूँ — पर उस के लिए आपको GitHub login/token देना पड़ेगा (ज्यादा सुरक्षित नहीं) — इसलिए मैं ZIP देना ही बेहतर मानता हूँ।

यदि आप चाहो तो मैं next message में **सरल हिंदी में** step-by-step screenshots/mini-guide भी लिख दूँ ताकि आप mobile से GitHub पर upload कर सको।
