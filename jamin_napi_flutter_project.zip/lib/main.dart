// Jamin Napi - simple Flutter app (main.dart)
// Dependencies (add to pubspec.yaml):
//   geolocator: ^9.0.2
//   permission_handler: ^10.2.0
//   path_provider: ^2.0.11
//   csv: ^5.0.0
//   shared_preferences: ^2.1.0
// This is a single-file prototype intended to run as a quick starter.

import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(JaminNapiApp());

class JaminNapiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jamin Napi',
      theme: ThemeData(primarySwatch: Colors.green),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
      locale: Locale('hi'),
    );
  }
}

class PointLatLng {
  final double lat;
  final double lon;
  PointLatLng(this.lat, this.lon);
  Map<String, dynamic> toJson() => {'lat': lat, 'lon': lon};
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<PointLatLng> points = [];
  double areaSqMeters = 0.0;
  SharedPreferences? prefs;

  @override
  void initState() {
    super.initState();
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    prefs = await SharedPreferences.getInstance();
    final saved = prefs?.getString('last_survey');
    if (saved != null) {
      try {
        final data = jsonDecode(saved) as List<dynamic>;
        setState(() {
          points = data
              .map((e) => PointLatLng((e['lat']) as double, (e['lon']) as double))
              .toList();
          areaSqMeters = _computeArea(points);
        });
      } catch (_) {}
    }
  }

  Future<void> _saveLocal() async {
    if (prefs == null) prefs = await SharedPreferences.getInstance();
    final encoded = jsonEncode(points.map((p) => p.toJson()).toList());
    await prefs!.setString('last_survey', encoded);
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('सर्वे सेव हो गया (local).')));
  }

  Future<void> _exportCsv() async {
    if (points.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('कोई पॉइंट नहीं है।')));
      return;
    }
    List<List<dynamic>> rows = [];
    rows.add(['index', 'latitude', 'longitude']);
    for (var i = 0; i < points.length; i++) {
      rows.add([i + 1, points[i].lat, points[i].lon]);
    }
    rows.add(['area_sqm', areaSqMeters]);

    String csv = const ListToCsvConverter().convert(rows);
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/survey_${DateTime.now().millisecondsSinceEpoch}.csv');
    await file.writeAsString(csv);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('CSV बन गया: ${file.path}')));
  }

  double _degToRad(double deg) => deg * math.pi / 180.0;

  // Convert lat/lon to planar X,Y in meters using equirectangular approx
  // Good for small parcels (few km). For large areas use geodesic library.
  Map<String, double> _latLonToXY(double lat, double lon, double refLat) {
    const R = 6378137.0; // Earth radius meters (WGS84)
    double x = _degToRad(lon) * R * math.cos(_degToRad(refLat));
    double y = _degToRad(lat) * R;
    return {'x': x, 'y': y};
  }

  double _computeArea(List<PointLatLng> pts) {
    if (pts.length < 3) return 0.0;
    double refLat = pts.map((p) => p.lat).reduce((a, b) => a + b) / pts.length;
    List<Map<String, double>> xy =
        pts.map((p) => _latLonToXY(p.lat, p.lon, refLat)).toList();
    double sum = 0.0;
    for (int i = 0; i < xy.length; i++) {
      final j = (i + 1) % xy.length;
      sum += xy[i]['x']! * xy[j]['y']! - xy[j]['x']! * xy[i]['y']!;
    }
    return (sum.abs() / 2.0);
  }

  Future<void> _addCurrentLocation() async {
    // request permission
    var status = await Permission.location.request();
    if (!status.isGranted) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('कृपया लोकेशन अनुमति दें।')));
      return;
    }
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('कृपया लोकेशन सर्विस ऑन करें।')));
      return;
    }
    Position pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    setState(() {
      points.add(PointLatLng(pos.latitude, pos.longitude));
      areaSqMeters = _computeArea(points);
    });
  }

  Future<void> _addManualDialog() async {
    final latC = TextEditingController();
    final lonC = TextEditingController();
    await showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: Text('मैन्युअल पॉइंट जोड़ें'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: latC,
                    keyboardType: TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(labelText: 'Latitude'),
                  ),
                  TextField(
                    controller: lonC,
                    keyboardType: TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(labelText: 'Longitude'),
                  ),
                ],
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('रद्द')),
                ElevatedButton(
                    onPressed: () {
                      final lat = double.tryParse(latC.text);
                      final lon = double.tryParse(lonC.text);
                      if (lat == null || lon == null) return;
                      setState(() {
                        points.add(PointLatLng(lat, lon));
                        areaSqMeters = _computeArea(points);
                      });
                      Navigator.pop(context);
                    },
                    child: Text('जोड़ें'))
              ],
            ));
  }

  void _clearAll() {
    setState(() {
      points.clear();
      areaSqMeters = 0.0;
    });
  }

  Future<void> _deletePoint(int idx) async {
    setState(() {
      points.removeAt(idx);
      areaSqMeters = _computeArea(points);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('जमीन नापी — सरल ऐप'),
        actions: [
          IconButton(
              tooltip: 'सेव लोकल',
              icon: Icon(Icons.save),
              onPressed: _saveLocal),
          IconButton(
              tooltip: 'CSV एक्सपोर्ट', icon: Icon(Icons.download), onPressed: _exportCsv),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(12.0),
        child: Column(
          children: [
            Card(
              child: ListTile(
                title: Text('क्षेत्रफल (लगभग)'),
                subtitle: Text('${areaSqMeters.toStringAsFixed(2)} वर्ग मीटर'),
              ),
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                    child: ElevatedButton.icon(
                        onPressed: _addCurrentLocation,
                        icon: Icon(Icons.gps_fixed),
                        label: Text('GPS से पॉइंट जोड़ें'))),
                SizedBox(width: 8),
                Expanded(
                    child: ElevatedButton.icon(
                        onPressed: _addManualDialog,
                        icon: Icon(Icons.edit_location),
                        label: Text('मैन्युअल जोड़ें'))),
              ],
            ),
            SizedBox(height: 8),
            Expanded(
                child: Card(
              child: Column(
                children: [
                  ListTile(
                    title: Text('पॉइंट्स (क्रमवार)'),
                    trailing: Text('कुल: ${points.length}'),
                  ),
                  Divider(height: 1),
                  Expanded(
                      child: ListView.builder(
                          itemCount: points.length,
                          itemBuilder: (ctx, i) {
                            final p = points[i];
                            return ListTile(
                              leading: CircleAvatar(child: Text('${i + 1}')),
                              title: Text('Lat: ${p.lat.toStringAsFixed(6)}'),
                              subtitle: Text('Lon: ${p.lon.toStringAsFixed(6)}'),
                              trailing: IconButton(
                                  icon: Icon(Icons.delete),
                                  onPressed: () => _deletePoint(i)),
                            );
                          }))
                ],
              ),
            )),
            SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                    child: OutlinedButton(onPressed: _clearAll, child: Text('साफ़ करें'))),
                SizedBox(width: 8),
                Expanded(
                    child: ElevatedButton(
                        onPressed: () async {
                          await _exportCsv();
                        },
                        child: Text('CSV बनाओ और सेव करो'))),
              ],
            )
          ],
        ),
      ),
    );
  }
}